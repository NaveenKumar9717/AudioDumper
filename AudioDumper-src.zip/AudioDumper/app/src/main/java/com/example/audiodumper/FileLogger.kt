package com.example.audiodumper

import android.util.Log
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** Logs to logcat (tag AudioDumper) AND to a file you can pull with adb. Rotates at ~5 MB. */
class FileLogger(private val file: File) {
    private val fmt = SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS", Locale.US)

    @Synchronized
    fun log(msg: String) {
        Log.i(TAG, msg)
        try {
            if (file.length() > 5_000_000) file.renameTo(File(file.path + ".1"))
            file.appendText("${fmt.format(Date())} $msg\n")
        } catch (e: Exception) {
            Log.e(TAG, "log write failed", e)
        }
    }

    companion object { const val TAG = "AudioDumper" }
}
