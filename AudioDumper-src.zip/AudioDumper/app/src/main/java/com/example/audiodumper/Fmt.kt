package com.example.audiodumper

import android.content.Context
import android.text.format.DateFormat
import android.text.format.Formatter
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

object Fmt {
    fun clock(ctx: Context, t: Long): String = DateFormat.getTimeFormat(ctx).format(Date(t))

    fun hm(ctx: Context, h: Int, m: Int): String {
        val c = Calendar.getInstance().apply {
            set(Calendar.HOUR_OF_DAY, h); set(Calendar.MINUTE, m)
        }
        return clock(ctx, c.timeInMillis)
    }

    private fun dayNumber(t: Long): Long {
        val c = Calendar.getInstance().apply { timeInMillis = t }
        return c.get(Calendar.YEAR) * 400L + c.get(Calendar.DAY_OF_YEAR)
    }

    /** "Today 09:00", "Tomorrow 09:00", "Fri 09:00", "3 Nov 09:00" */
    fun whenText(ctx: Context, t: Long): String {
        val now = System.currentTimeMillis()
        val diff = ((t - now) / 86_400_000L)
        val day = when {
            dayNumber(t) == dayNumber(now) -> "Today"
            dayNumber(t) == dayNumber(now + 86_400_000L) -> "Tomorrow"
            diff in 0..5 -> SimpleDateFormat("EEE", Locale.getDefault()).format(Date(t))
            else -> SimpleDateFormat("d MMM", Locale.getDefault()).format(Date(t))
        }
        return "$day ${clock(ctx, t)}"
    }

    fun dateTime(ctx: Context, t: Long): String =
        SimpleDateFormat("d MMM", Locale.getDefault()).format(Date(t)) + ", " + clock(ctx, t)

    /** 90 -> "1h 30m" */
    fun dur(min: Int): String {
        val h = min / 60
        val m = min % 60
        return when {
            h == 0 -> "${m} min"
            m == 0 -> "${h}h"
            else -> "${h}h ${m}m"
        }
    }

    /** 3723000 -> "1:02:03", 63000 -> "01:03" */
    fun elapsed(ms: Long): String {
        val s = (ms / 1000).coerceAtLeast(0)
        val h = s / 3600
        val m = (s % 3600) / 60
        val sec = s % 60
        return if (h > 0) String.format(Locale.US, "%d:%02d:%02d", h, m, sec)
        else String.format(Locale.US, "%02d:%02d", m, sec)
    }

    fun size(ctx: Context, bytes: Long): String = Formatter.formatShortFileSize(ctx, bytes)

    fun daysText(days: Int): String = when (days) {
        Job.EVERY_DAY -> "Every day"
        Job.WEEKDAYS -> "Weekdays"
        Job.WEEKENDS -> "Weekends"
        0 -> "Once"
        else -> (0..6).filter { days and (1 shl it) != 0 }.joinToString(" ") { Job.DAY_SHORT[it] }
    }
}
