package com.example.audiodumper

import android.util.Log
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** Log to logcat and to a file shown in the app's Log tab. Rotates at ~2 MB. */
object AppLog {
    const val TAG = "AudioDumper"
    private var file: File? = null
    private val fmt = SimpleDateFormat("dd MMM HH:mm:ss", Locale.US)

    fun init(f: File) { file = f }

    @Synchronized fun log(msg: String) {
        Log.i(TAG, msg)
        val f = file ?: return
        try {
            if (f.length() > 2_000_000) f.renameTo(File(f.path + ".1"))
            f.appendText("${fmt.format(Date())}  $msg\n")
        } catch (e: Exception) {
            Log.e(TAG, "log write failed", e)
        }
    }

    @Synchronized fun tail(n: Int): String {
        val f = file ?: return "(no log)"
        return try {
            if (!f.exists()) "(log is empty)" else f.readLines().takeLast(n).joinToString("\n")
        } catch (e: Exception) {
            "log read error: $e"
        }
    }

    @Synchronized fun clear() {
        val f = file ?: return
        f.delete()
        File(f.path + ".1").delete()
    }
}
