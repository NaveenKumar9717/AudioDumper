package com.example.audiodumper

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

/**
 * After a reboot or app update the scheduler is gone, and Android does not allow
 * a microphone service to start from the background. So we remind the user with
 * a notification; one tap turns it back on.
 */
class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        AppLog.log("system event: ${intent.action}")
        if (Repo.armedWanted && Repo.jobs.any { it.enabled }) {
            val why = if (intent.action == Intent.ACTION_MY_PACKAGE_REPLACED) "The app was updated"
            else "The phone restarted"
            RecorderService.postRearm(context, why)
        }
    }
}
