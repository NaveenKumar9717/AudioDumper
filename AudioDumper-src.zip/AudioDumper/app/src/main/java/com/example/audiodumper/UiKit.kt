package com.example.audiodumper

import android.content.Context
import android.content.res.ColorStateList
import android.content.res.Configuration
import android.graphics.Typeface
import android.graphics.drawable.Drawable
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.RippleDrawable
import android.util.TypedValue
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.HorizontalScrollView
import android.widget.LinearLayout
import android.widget.TextView

/** App colours, light and dark. */
class Pal(ctx: Context) {
    val night = (ctx.resources.configuration.uiMode and Configuration.UI_MODE_NIGHT_MASK) ==
        Configuration.UI_MODE_NIGHT_YES

    private fun c(light: Long, dark: Long): Int = (if (night) dark else light).toInt()

    val bg = c(0xFFF2F3F7, 0xFF0E1014)
    val card = c(0xFFFFFFFF, 0xFF1A1D24)
    val chip = c(0xFFE8EAF1, 0xFF262A33)
    val text = c(0xFF15171C, 0xFFECEDF1)
    val sub = c(0xFF5E6470, 0xFF9AA0AB)
    val accent = c(0xFF3F51D9, 0xFF8E9BFF)
    val onAccent = c(0xFFFFFFFF, 0xFF0E1014)
    val accentSoft = c(0xFFE2E6FF, 0xFF2A2F4D)
    val red = c(0xFFD93025, 0xFFFF6B6B)
    val redSoft = c(0xFFFCE8E6, 0xFF3D2224)
    val green = c(0xFF1E8E3E, 0xFF5CD68A)
    val warn = c(0xFFB06000, 0xFFFFC266)
    val ripple = c(0x22000000, 0x33FFFFFF)
}

enum class Kind { FILLED, TONAL, DANGER, PLAIN }

/** Small helpers to build good-looking views in code (no XML, no extra libraries). */
class UiKit(private val ctx: Context, private val p: Pal) {
    companion object {
        const val MATCH = ViewGroup.LayoutParams.MATCH_PARENT
        const val WRAP = ViewGroup.LayoutParams.WRAP_CONTENT
    }

    fun dp(v: Number): Int = TypedValue.applyDimension(
        TypedValue.COMPLEX_UNIT_DIP, v.toFloat(), ctx.resources.displayMetrics
    ).toInt()

    fun round(color: Int, radiusDp: Int): GradientDrawable = GradientDrawable().apply {
        setColor(color)
        cornerRadius = dp(radiusDp).toFloat()
    }

    fun rippleBg(color: Int, radiusDp: Int): Drawable =
        RippleDrawable(ColorStateList.valueOf(p.ripple), round(color, radiusDp), round(0xFFFFFFFF.toInt(), radiusDp))

    fun clickable(v: View, color: Int, radiusDp: Int, onClick: () -> Unit) {
        v.background = rippleBg(color, radiusDp)
        v.isClickable = true
        v.isFocusable = true
        v.setOnClickListener { onClick() }
    }

    fun text(s: String, sp: Float = 15f, color: Int = p.text, bold: Boolean = false): TextView =
        TextView(ctx).apply {
            text = s
            textSize = sp
            setTextColor(color)
            if (bold) typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            setLineSpacing(0f, 1.1f)
        }

    fun section(s: String): TextView = text(s.uppercase(), 12f, p.sub, bold = true).apply {
        letterSpacing = 0.08f
        setPadding(0, dp(18), 0, dp(6))
    }

    fun <T : View> place(
        v: T, w: Int = MATCH, h: Int = WRAP, weight: Float = 0f,
        top: Int = 0, bottom: Int = 0, start: Int = 0, end: Int = 0,
    ): T {
        v.layoutParams = LinearLayout.LayoutParams(w, h, weight).apply {
            topMargin = dp(top); bottomMargin = dp(bottom)
            marginStart = dp(start); marginEnd = dp(end)
        }
        return v
    }

    fun card(): LinearLayout = LinearLayout(ctx).apply {
        orientation = LinearLayout.VERTICAL
        background = round(p.card, 22)
        setPadding(dp(18), dp(16), dp(18), dp(16))
        layoutParams = LinearLayout.LayoutParams(MATCH, WRAP).apply { bottomMargin = dp(12) }
    }

    fun row(): LinearLayout = LinearLayout(ctx).apply {
        orientation = LinearLayout.HORIZONTAL
        gravity = Gravity.CENTER_VERTICAL
    }

    fun button(label: String, kind: Kind, onClick: () -> Unit): TextView {
        val (bgc, fg) = when (kind) {
            Kind.FILLED -> p.accent to p.onAccent
            Kind.TONAL -> p.accentSoft to p.accent
            Kind.DANGER -> p.red to 0xFFFFFFFF.toInt()
            Kind.PLAIN -> p.chip to p.text
        }
        return text(label, 15f, fg, bold = true).apply {
            gravity = Gravity.CENTER
            setPadding(dp(20), dp(12), dp(20), dp(12))
            clickable(this, bgc, 24, onClick)
        }
    }

    fun chip(label: String, onClick: () -> Unit): TextView = text(label, 14f).apply {
        gravity = Gravity.CENTER
        setPadding(dp(14), dp(8), dp(14), dp(8))
        setOnClickListener { onClick() }
        styleChip(this, false)
    }

    fun styleChip(tv: TextView, selected: Boolean) {
        tv.background = rippleBg(if (selected) p.accent else p.chip, 20)
        tv.setTextColor(if (selected) p.onAccent else p.text)
        tv.isClickable = true
    }

    /** Horizontally scrollable row of chips with spacing. */
    fun chipRow(chips: List<View>): HorizontalScrollView {
        val r = row()
        chips.forEachIndexed { i, c -> r.addView(place(c, w = WRAP, end = if (i < chips.size - 1) 8 else 0)) }
        return HorizontalScrollView(ctx).apply {
            isHorizontalScrollBarEnabled = false
            addView(r)
        }
    }
}
