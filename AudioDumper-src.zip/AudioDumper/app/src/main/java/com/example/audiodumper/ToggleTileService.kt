package com.example.audiodumper

import android.annotation.SuppressLint
import android.app.PendingIntent
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.os.Build
import android.service.quicksettings.Tile
import android.service.quicksettings.TileService

/** Quick Settings tile: tap to turn the scheduler on/off. */
class ToggleTileService : TileService() {

    companion object {
        fun refresh(context: Context) {
            try {
                requestListeningState(context, ComponentName(context, ToggleTileService::class.java))
            } catch (_: Exception) {}
        }
    }

    override fun onStartListening() = refreshTile()

    @SuppressLint("StartActivityAndCollapseDeprecated")
    override fun onClick() {
        if (Status.armed) {
            RecorderService.send(this, RecorderService.ACTION_DISARM)
            return
        }
        val i = Intent(this, MainActivity::class.java)
            .setAction(RecorderService.ACTION_ARM)
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        if (Build.VERSION.SDK_INT >= 34) {
            startActivityAndCollapse(
                PendingIntent.getActivity(
                    this, 0, i, PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
                )
            )
        } else {
            @Suppress("DEPRECATION")
            startActivityAndCollapse(i)
        }
    }

    private fun refreshTile() {
        val t = qsTile ?: return
        t.state = if (Status.armed) Tile.STATE_ACTIVE else Tile.STATE_INACTIVE
        t.label = "AudioDumper"
        t.subtitle = when {
            Status.recName != null -> "Recording"
            Status.armed -> "Scheduler on"
            else -> "Off"
        }
        t.updateTile()
    }
}
