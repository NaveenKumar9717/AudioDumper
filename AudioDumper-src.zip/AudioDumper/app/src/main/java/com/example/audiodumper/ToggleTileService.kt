package com.example.audiodumper

import android.annotation.SuppressLint
import android.app.PendingIntent
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.os.Build
import android.service.quicksettings.Tile
import android.service.quicksettings.TileService

/**
 * Quick Settings tile: pull down the notification shade -> edit tiles -> add "AudioDumper".
 * Tap = toggle. Start goes through MainActivity (needed for mic access); stop is direct.
 */
class ToggleTileService : TileService() {

    companion object {
        fun refresh(context: Context) {
            requestListeningState(context, ComponentName(context, ToggleTileService::class.java))
        }
    }

    override fun onStartListening() = refreshTile()

    @SuppressLint("StartActivityAndCollapseDeprecated")
    override fun onClick() {
        if (RecorderService.isRunning) {
            stopService(Intent(this, RecorderService::class.java))
            refreshTile()
            return
        }
        val i = Intent(this, MainActivity::class.java)
            .setAction(MainActivity.ACTION_START)
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        if (Build.VERSION.SDK_INT >= 34) {
            startActivityAndCollapse(
                PendingIntent.getActivity(
                    this, 0, i, PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
                )
            )
        } else {
            @Suppress("DEPRECATION")
            startActivityAndCollapse(i)
        }
    }

    private fun refreshTile() {
        qsTile?.apply {
            state = if (RecorderService.isRunning) Tile.STATE_ACTIVE else Tile.STATE_INACTIVE
            label = "AudioDumper"
            if (Build.VERSION.SDK_INT >= 29) subtitle = if (RecorderService.isRunning) "Running" else "Stopped"
            updateTile()
        }
    }
}
