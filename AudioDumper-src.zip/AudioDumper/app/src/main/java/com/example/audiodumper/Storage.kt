package com.example.audiodumper

import android.content.ContentValues
import android.content.Context
import android.net.Uri
import android.os.ParcelFileDescriptor
import android.provider.DocumentsContract
import android.provider.MediaStore
import java.io.IOException

/**
 * Where recordings go:
 *  - default: Internal storage/Recordings/AudioDumper (MediaStore, no permission needed)
 *  - or any folder the user picks (Storage Access Framework, persisted permission)
 */
object Storage {
    const val DEFAULT_DIR = "Recordings/AudioDumper"
    private const val MIME = "audio/mp4"

    class Output(val uri: Uri, val pfd: ParcelFileDescriptor, val mediaStore: Boolean, val label: String)

    fun folderLabel(): String = Repo.settings.folderLabel ?: "Internal storage/$DEFAULT_DIR"

    fun create(ctx: Context, name: String): Output {
        val cr = ctx.contentResolver
        val tree = Repo.settings.folderUri
        if (tree != null) {
            val treeUri = Uri.parse(tree)
            val parent = DocumentsContract.buildDocumentUriUsingTree(
                treeUri, DocumentsContract.getTreeDocumentId(treeUri)
            )
            val doc = DocumentsContract.createDocument(cr, parent, MIME, name)
                ?: throw IOException("could not create file in chosen folder")
            val pfd = cr.openFileDescriptor(doc, "rw")
                ?: throw IOException("could not open file in chosen folder")
            return Output(doc, pfd, false, "${folderLabel()}/$name")
        }
        val values = ContentValues().apply {
            put(MediaStore.MediaColumns.DISPLAY_NAME, name)
            put(MediaStore.MediaColumns.MIME_TYPE, MIME)
            put(MediaStore.MediaColumns.RELATIVE_PATH, DEFAULT_DIR)
            put(MediaStore.MediaColumns.IS_PENDING, 1)
        }
        val uri = cr.insert(MediaStore.Audio.Media.getContentUri(MediaStore.VOLUME_EXTERNAL_PRIMARY), values)
            ?: throw IOException("MediaStore insert failed")
        val pfd = cr.openFileDescriptor(uri, "rw")
        if (pfd == null) {
            cr.delete(uri, null, null)
            throw IOException("could not open MediaStore file")
        }
        return Output(uri, pfd, true, "$DEFAULT_DIR/$name")
    }

    /** Closes the file and makes it visible. Returns size in bytes. */
    fun finish(ctx: Context, out: Output): Long {
        val size = try { out.pfd.statSize } catch (e: Exception) { -1L }
        try { out.pfd.close() } catch (_: Exception) {}
        if (out.mediaStore) {
            val v = ContentValues().apply { put(MediaStore.MediaColumns.IS_PENDING, 0) }
            try { ctx.contentResolver.update(out.uri, v, null, null) } catch (e: Exception) {
                AppLog.log("could not publish ${out.label}: $e")
            }
        }
        return size
    }

    fun discard(ctx: Context, out: Output) {
        try { out.pfd.close() } catch (_: Exception) {}
        delete(ctx, out.uri)
    }

    fun delete(ctx: Context, uri: Uri): Boolean = try {
        if (DocumentsContract.isDocumentUri(ctx, uri)) {
            DocumentsContract.deleteDocument(ctx.contentResolver, uri)
        } else {
            ctx.contentResolver.delete(uri, null, null) > 0
        }
    } catch (e: Exception) {
        AppLog.log("delete failed for $uri: $e")
        false
    }

    /** "primary:Music/Calls" -> "Internal storage/Music/Calls" */
    fun labelForTree(uri: Uri): String = try {
        val id = DocumentsContract.getTreeDocumentId(uri)
        val parts = id.split(":", limit = 2)
        val vol = if (parts[0] == "primary") "Internal storage" else "SD card"
        val path = if (parts.size > 1) parts[1] else ""
        if (path.isEmpty()) vol else "$vol/$path"
    } catch (e: Exception) {
        uri.toString()
    }
}
