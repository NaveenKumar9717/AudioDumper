package com.example.audiodumper

import android.content.Context
import android.content.SharedPreferences
import android.os.Handler
import android.os.Looper
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.CopyOnWriteArraySet

/** Jobs, recording history and settings, stored in SharedPreferences as JSON. */
object Repo {
    private lateinit var prefs: SharedPreferences
    private val main = Handler(Looper.getMainLooper())
    private val listeners = CopyOnWriteArraySet<() -> Unit>()

    @Volatile var jobs: List<Job> = emptyList()
        private set
    @Volatile var recordings: List<RecEntry> = emptyList()
        private set
    @Volatile var settings: Settings = Settings()
        private set

    fun init(ctx: Context) {
        prefs = ctx.getSharedPreferences("audiodumper", Context.MODE_PRIVATE)
        jobs = parse(prefs.getString("jobs", null)) { Job.fromJson(it) }
        recordings = parse(prefs.getString("recs", null)) { RecEntry.fromJson(it) }
        settings = Settings(
            folderUri = prefs.getString("folderUri", null),
            folderLabel = prefs.getString("folderLabel", null),
            quality = prefs.getInt("quality", 1).coerceIn(0, 2),
            source = prefs.getInt("source", 0).coerceIn(0, Audio.SOURCES.size - 1),
        )
    }

    private fun <T> parse(s: String?, f: (JSONObject) -> T): List<T> = try {
        val a = JSONArray(s ?: "[]")
        (0 until a.length()).map { f(a.getJSONObject(it)) }
    } catch (e: Exception) {
        emptyList()
    }

    private fun <T> store(key: String, list: List<T>, f: (T) -> JSONObject) {
        val a = JSONArray()
        list.forEach { a.put(f(it)) }
        prefs.edit().putString(key, a.toString()).apply()
    }

    @Synchronized fun saveJob(j: Job) {
        val i = jobs.indexOfFirst { it.id == j.id }
        jobs = if (i >= 0) jobs.toMutableList().also { it[i] = j } else jobs + j
        store("jobs", jobs) { it.toJson() }
        changed()
    }

    @Synchronized fun deleteJob(id: Long) {
        jobs = jobs.filter { it.id != id }
        store("jobs", jobs) { it.toJson() }
        changed()
    }

    @Synchronized fun addRecording(e: RecEntry) {
        recordings = (listOf(e) + recordings).take(300)
        store("recs", recordings) { it.toJson() }
        changed()
    }

    @Synchronized fun removeRecording(uri: String) {
        recordings = recordings.filter { it.uri != uri }
        store("recs", recordings) { it.toJson() }
        changed()
    }

    @Synchronized fun updateSettings(f: (Settings) -> Settings) {
        settings = f(settings)
        prefs.edit()
            .putString("folderUri", settings.folderUri)
            .putString("folderLabel", settings.folderLabel)
            .putInt("quality", settings.quality)
            .putInt("source", settings.source)
            .apply()
        changed()
    }

    /** True while the user wants the scheduler on (survives process death / reboot). */
    var armedWanted: Boolean
        get() = prefs.getBoolean("armed", false)
        set(v) { prefs.edit().putBoolean("armed", v).apply() }

    fun addListener(l: () -> Unit) { listeners.add(l) }
    fun removeListener(l: () -> Unit) { listeners.remove(l) }
    fun changed() { main.post { listeners.forEach { it() } } }
}
