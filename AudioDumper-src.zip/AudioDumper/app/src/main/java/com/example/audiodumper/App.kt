package com.example.audiodumper

import android.app.Application
import java.io.File

class App : Application() {
    override fun onCreate() {
        super.onCreate()
        AppLog.init(File(getExternalFilesDir(null) ?: filesDir, "service.log"))
        Repo.init(this)
    }
}
