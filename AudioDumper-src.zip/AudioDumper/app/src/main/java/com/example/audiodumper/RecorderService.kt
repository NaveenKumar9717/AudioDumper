package com.example.audiodumper

import android.annotation.SuppressLint
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.ServiceInfo
import android.media.AudioFormat
import android.media.AudioRecord
import android.media.MediaRecorder
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.PowerManager
import android.os.SystemClock
import java.io.File
import kotlin.math.abs
import kotlin.math.max

/**
 * Step 1: long-running foreground service.
 *  - logs a heartbeat every 10 s (uptime, screen state, mic peak level, silenced flag)
 *  - keeps the mic open with a tiny AudioRecord "probe" so we can PROVE the mic
 *    still hears sound when the phone is locked (peak > 0, silenced=false).
 * Real recording to files comes in step 2 and will replace the probe.
 */
class RecorderService : Service() {

    companion object {
        const val ACTION_STOP = "com.example.audiodumper.STOP"
        private const val CHANNEL_ID = "recorder"
        private const val NOTIF_ID = 1
        private const val HEARTBEAT_MS = 10_000L

        @Volatile var isRunning = false
            private set
    }

    private lateinit var logger: FileLogger
    private val handler = Handler(Looper.getMainLooper())
    private var wakeLock: PowerManager.WakeLock? = null
    private var startTime = 0L

    // mic probe
    private var audioRecord: AudioRecord? = null
    private var probeThread: Thread? = null
    @Volatile private var probing = false
    @Volatile private var windowPeak = 0

    private val heartbeat = object : Runnable {
        override fun run() {
            val pm = getSystemService(PowerManager::class.java)
            val silenced = try {
                audioRecord?.activeRecordingConfiguration?.isClientSilenced
            } catch (e: Exception) { null }
            val peak = windowPeak
            windowPeak = 0
            logger.log(
                "heartbeat uptime=${(SystemClock.elapsedRealtime() - startTime) / 1000}s " +
                "screenOn=${pm.isInteractive} micPeak=$peak silenced=$silenced"
            )
            handler.postDelayed(this, HEARTBEAT_MS)
        }
    }

    private val screenReceiver = object : BroadcastReceiver() {
        override fun onReceive(c: Context, i: Intent) = logger.log("event ${i.action}")
    }

    override fun onCreate() {
        super.onCreate()
        logger = FileLogger(File(getExternalFilesDir(null), "service.log"))
        createChannel()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            logger.log("stop requested (notification/app)")
            stopSelf()
            return START_NOT_STICKY
        }
        if (isRunning) {
            logger.log("start ignored: already running")
            return START_STICKY
        }

        try {
            startForeground(NOTIF_ID, buildNotification(), ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE)
        } catch (e: Exception) {
            // Happens if started from background (e.g. system restart after kill) on Android 14+
            logger.log("startForeground FAILED: $e  -> open the app to start")
            stopSelf()
            return START_NOT_STICKY
        }

        isRunning = true
        startTime = SystemClock.elapsedRealtime()
        logger.log("service STARTED (restartedBySystem=${intent == null})")
        ToggleTileService.refresh(this)

        wakeLock = getSystemService(PowerManager::class.java)
            .newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "AudioDumper::service")
            .apply { acquire() }

        val filter = IntentFilter().apply {
            addAction(Intent.ACTION_SCREEN_OFF)
            addAction(Intent.ACTION_SCREEN_ON)
            addAction(Intent.ACTION_USER_PRESENT)
        }
        if (Build.VERSION.SDK_INT >= 33) {
            registerReceiver(screenReceiver, filter, Context.RECEIVER_NOT_EXPORTED)
        } else {
            registerReceiver(screenReceiver, filter)
        }

        startMicProbe()
        handler.post(heartbeat)
        return START_STICKY
    }

    @SuppressLint("MissingPermission") // permission is checked in MainActivity before start
    private fun startMicProbe() {
        val rate = 16_000
        val minBuf = AudioRecord.getMinBufferSize(
            rate, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT
        )
        val rec = try {
            AudioRecord(
                MediaRecorder.AudioSource.MIC, rate,
                AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT, minBuf * 2
            )
        } catch (e: Exception) {
            logger.log("AudioRecord create failed: $e"); return
        }
        if (rec.state != AudioRecord.STATE_INITIALIZED) {
            logger.log("AudioRecord not initialized (mic busy or no permission)")
            rec.release(); return
        }
        audioRecord = rec
        probing = true
        probeThread = Thread {
            val buf = ShortArray(minBuf)
            rec.startRecording()
            logger.log("mic probe started, recordingState=${rec.recordingState}")
            while (probing) {
                val n = rec.read(buf, 0, buf.size)
                if (n > 0) {
                    var p = 0
                    for (k in 0 until n) p = max(p, abs(buf[k].toInt()))
                    windowPeak = max(windowPeak, p)
                } else if (n < 0) {
                    logger.log("mic read error $n"); break
                }
            }
            try { rec.stop() } catch (_: Exception) {}
            rec.release()
            logger.log("mic probe stopped")
        }.apply { name = "mic-probe"; start() }
    }

    override fun onTaskRemoved(rootIntent: Intent?) {
        logger.log("app swiped from recents (service keeps running)")
    }

    override fun onDestroy() {
        handler.removeCallbacks(heartbeat)
        probing = false
        probeThread?.join(1000)
        audioRecord = null
        if (isRunning) try { unregisterReceiver(screenReceiver) } catch (_: Exception) {}
        wakeLock?.let { if (it.isHeld) it.release() }
        isRunning = false
        logger.log("service DESTROYED")
        ToggleTileService.refresh(this)
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    private fun createChannel() {
        val ch = NotificationChannel(CHANNEL_ID, "Recorder", NotificationManager.IMPORTANCE_LOW)
        getSystemService(NotificationManager::class.java).createNotificationChannel(ch)
    }

    private fun buildNotification(): Notification {
        val openApp = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE
        )
        val stop = PendingIntent.getService(
            this, 1, Intent(this, RecorderService::class.java).setAction(ACTION_STOP),
            PendingIntent.FLAG_IMMUTABLE
        )
        return Notification.Builder(this, CHANNEL_ID)
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .setContentTitle("AudioDumper running")
            .setContentText("Service active")
            .setOngoing(true)
            .setContentIntent(openApp)
            .addAction(Notification.Action.Builder(null, "Stop", stop).build())
            .build()
    }
}
