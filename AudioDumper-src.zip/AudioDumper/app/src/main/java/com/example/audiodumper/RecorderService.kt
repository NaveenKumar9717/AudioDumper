package com.example.audiodumper

import android.annotation.SuppressLint
import android.app.AlarmManager
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.media.MediaRecorder
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.PowerManager
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.max

/**
 * The scheduler. Started ONCE from the app screen (that is what grants microphone access
 * on Android 12+), then stays alive as a foreground service and starts/stops recordings
 * itself at the job times. Exact alarms wake it up from deep sleep.
 */
class RecorderService : Service() {

    companion object {
        const val ACTION_ARM = "com.example.audiodumper.ARM"
        const val ACTION_DISARM = "com.example.audiodumper.DISARM"
        const val ACTION_CHECK = "com.example.audiodumper.CHECK"
        const val ACTION_REC_NOW = "com.example.audiodumper.REC_NOW"
        const val ACTION_REC_STOP = "com.example.audiodumper.REC_STOP"
        const val EXTRA_MINUTES = "minutes"
        const val MANUAL_ID = -1L

        private const val CH_STATUS = "status"
        private const val CH_ALERT = "alerts"
        private const val NOTIF_ID = 1
        private const val ALERT_REARM_ID = 2
        private const val ALERT_SILENT_ID = 3
        private const val ALERT_FAIL_ID = 4
        private const val TOL = 1000L

        /** Use only for actions on an already-running scheduler (CHECK, REC_STOP, DISARM). */
        fun send(ctx: Context, action: String) {
            try {
                ctx.startService(Intent(ctx, RecorderService::class.java).setAction(action))
            } catch (e: Exception) {
                AppLog.log("send $action failed: $e")
            }
        }

        /** ARM or REC_NOW. Must be called while the app is on screen. */
        fun startFromForeground(ctx: Context, action: String, minutes: Int = 0) {
            ctx.startForegroundService(
                Intent(ctx, RecorderService::class.java).setAction(action).putExtra(EXTRA_MINUTES, minutes)
            )
        }

        fun ensureChannels(ctx: Context) {
            val nm = ctx.getSystemService(NotificationManager::class.java)
            nm.createNotificationChannel(
                NotificationChannel(CH_STATUS, "Scheduler status", NotificationManager.IMPORTANCE_LOW)
            )
            nm.createNotificationChannel(
                NotificationChannel(CH_ALERT, "Alerts", NotificationManager.IMPORTANCE_HIGH)
            )
        }

        fun postAlert(ctx: Context, id: Int, title: String, text: String, rearm: Boolean) {
            ensureChannels(ctx)
            val open = Intent(ctx, MainActivity::class.java)
            if (rearm) open.action = ACTION_ARM
            val pi = PendingIntent.getActivity(
                ctx, 10 + id, open, PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
            )
            val n = Notification.Builder(ctx, CH_ALERT)
                .setSmallIcon(android.R.drawable.stat_notify_error)
                .setContentTitle(title)
                .setContentText(text)
                .setStyle(Notification.BigTextStyle().bigText(text))
                .setContentIntent(pi)
                .setAutoCancel(true)
                .build()
            try {
                ctx.getSystemService(NotificationManager::class.java).notify(id, n)
            } catch (e: Exception) {
                AppLog.log("alert failed: $e")
            }
        }

        fun postRearm(ctx: Context, why: String) = postAlert(
            ctx, ALERT_REARM_ID, "AudioDumper scheduler is OFF",
            "$why. Tap to turn the scheduler back on, or your jobs won't record.", true
        )
    }

    private class Session(
        val jobId: Long,
        val name: String,
        val startedAt: Long,
        var endsAt: Long?,
        val splitMs: Long,
    ) {
        var recorder: MediaRecorder? = null
        var out: Storage.Output? = null
        var chunkStart = 0L
        var chunkName = ""
        var chunkPeak = 0
        var windowPeak = 0
        var silenced = false
    }

    private val handler = Handler(Looper.getMainLooper())
    private var armed = false
    private var sess: Session? = null
    private val skip = HashMap<Long, Long>() // jobId -> skip until
    private var wakeLock: PowerManager.WakeLock? = null
    private var pollCount = 0

    private val checkRunnable = Runnable { evaluate() }

    private val ampPoll = object : Runnable {
        override fun run() {
            val s = sess ?: return
            val r = s.recorder
            if (r != null) {
                val a = try { r.maxAmplitude } catch (e: Exception) { 0 }
                s.chunkPeak = max(s.chunkPeak, a)
                s.windowPeak = max(s.windowPeak, a)
                val sil = try { r.activeRecordingConfiguration?.isClientSilenced == true } catch (e: Exception) { false }
                if (sil && !s.silenced) AppLog.log("WARNING: Android is silencing the microphone for this app")
                s.silenced = sil
                pollCount++
                if (pollCount % 60 == 0) {
                    AppLog.log("recording '${s.name}' level=${s.windowPeak} silenced=$sil")
                    s.windowPeak = 0
                }
            }
            handler.postDelayed(this, 1000)
        }
    }

    override fun onCreate() {
        super.onCreate()
        ensureChannels(this)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val action = intent?.action
        when (action) {
            ACTION_ARM, ACTION_REC_NOW -> {
                if (!goForeground()) {
                    stopSelf()
                    return START_NOT_STICKY
                }
                if (!armed) {
                    armed = true
                    Repo.armedWanted = true
                    AppLog.log("scheduler ON")
                    getSystemService(NotificationManager::class.java).cancel(ALERT_REARM_ID)
                }
            }
            ACTION_DISARM -> {
                disarm()
                return START_NOT_STICKY
            }
            else -> if (!armed) {
                // System restarted us after a kill, or an alarm fired while we were dead.
                // We can't regain microphone access from the background -> ask the user.
                AppLog.log(
                    if (intent == null) "service was killed and restarted by Android; needs re-arm"
                    else "$action received but scheduler is off"
                )
                if (Repo.armedWanted && (intent == null || action == ACTION_CHECK)) {
                    postRearm(this, "Android stopped the scheduler")
                }
                stopSelf()
                return START_NOT_STICKY
            }
        }

        when (action) {
            ACTION_REC_NOW -> startManual(intent?.getIntExtra(EXTRA_MINUTES, 0) ?: 0)
            ACTION_REC_STOP -> stopByUser()
        }
        evaluate()
        return START_STICKY
    }

    private fun goForeground(): Boolean = try {
        startForeground(NOTIF_ID, buildNotification(), ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE)
        true
    } catch (e: Exception) {
        AppLog.log("could not start foreground service: $e")
        postRearm(this, "The scheduler could not start in the background")
        false
    }

    // ---------------------------------------------------------------- scheduling

    private fun evaluate() {
        if (!armed) return
        val now = System.currentTimeMillis()
        skip.entries.removeAll { it.value <= now }
        val jobs = Repo.jobs

        // 1. Is the current job recording still valid?
        sess?.let { s ->
            if (s.jobId != MANUAL_ID) {
                val job = jobs.find { it.id == s.jobId }
                val w = if (job != null && job.enabled) job.windowAt(now) else null
                if (w == null) stopSession("job window ended or job changed", natural = job != null && job.enabled)
                else s.endsAt = w[1]
            }
        }
        // 2. Time to stop?
        sess?.let { s ->
            val end = s.endsAt
            if (end != null && now >= end - TOL) stopSession("finished", natural = true)
        }
        // 3. Time for a new file?
        sess?.let { s ->
            if (s.splitMs > 0 && now >= s.chunkStart + s.splitMs - TOL) rotate()
        }
        // 4. Should a job start?
        if (sess == null) {
            val t = now + TOL
            var best: Job? = null
            var bestWin: LongArray? = null
            for (j in jobs) {
                if (!j.enabled || skip.containsKey(j.id)) continue
                val w = j.windowAt(t) ?: continue
                if (bestWin == null || w[0] < bestWin[0]) { best = j; bestWin = w }
            }
            if (best != null && bestWin != null) startJob(best, bestWin[1])
        }

        // 5. Next wake-up
        var next = Long.MAX_VALUE
        sess?.let { s ->
            s.endsAt?.let { if (it > now) next = minOf(next, it) }
            if (s.splitMs > 0) next = minOf(next, s.chunkStart + s.splitMs)
        }
        var nextJob: Job? = null
        var nextJobAt = Long.MAX_VALUE
        for (j in jobs) {
            if (!j.enabled) continue
            val ns = j.nextStart(now) ?: continue
            if (ns < nextJobAt) { nextJobAt = ns; nextJob = j }
        }
        next = minOf(next, nextJobAt)
        scheduleWake(if (next == Long.MAX_VALUE) null else next)
        Status.nextText = nextJob?.let { "${it.name} · ${Fmt.whenText(this, nextJobAt)}" }
        publish()
    }

    private fun scheduleWake(at: Long?) {
        handler.removeCallbacks(checkRunnable)
        val am = getSystemService(AlarmManager::class.java)
        val pi = PendingIntent.getService(
            this, 1, Intent(this, RecorderService::class.java).setAction(ACTION_CHECK),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        am.cancel(pi)
        if (at == null) return
        handler.postDelayed(checkRunnable, (at - System.currentTimeMillis()).coerceAtLeast(0))
        try {
            if (am.canScheduleExactAlarms()) am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, pi)
            else am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, pi)
        } catch (e: Exception) {
            AppLog.log("alarm failed: $e")
        }
    }

    // ---------------------------------------------------------------- sessions

    private fun startJob(job: Job, end: Long) {
        AppLog.log("job '${job.name}' starting, until ${Fmt.clock(this, end)}")
        begin(Session(job.id, job.name, System.currentTimeMillis(), end, job.splitMin * 60_000L))
    }

    private fun startManual(minutes: Int) {
        sess?.let { s ->
            if (s.jobId != MANUAL_ID) skip[s.jobId] = s.endsAt ?: System.currentTimeMillis()
            stopSession("replaced by manual recording", natural = false)
        }
        val now = System.currentTimeMillis()
        val end = if (minutes > 0) now + minutes * 60_000L else null
        AppLog.log("manual recording " + (if (minutes > 0) "for $minutes min" else "until stopped"))
        begin(Session(MANUAL_ID, "Manual", now, end, 0))
    }

    private fun stopByUser() {
        val s = sess ?: return
        if (s.jobId != MANUAL_ID) {
            skip[s.jobId] = s.endsAt ?: System.currentTimeMillis()
            Repo.jobs.find { it.id == s.jobId }?.let { if (it.isOnce) Repo.saveJob(it.copy(enabled = false)) }
        }
        stopSession("stopped by user", natural = false)
    }

    private fun begin(s: Session) {
        sess = s
        val pm = getSystemService(PowerManager::class.java)
        val holdMs = ((s.endsAt ?: (System.currentTimeMillis() + 24 * 3_600_000L)) -
            System.currentTimeMillis() + 600_000L).coerceAtLeast(60_000L)
        wakeLock = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "AudioDumper::rec").apply {
            setReferenceCounted(false)
            acquire(holdMs)
        }
        if (!openChunk()) {
            postAlert(this, ALERT_FAIL_ID, "Recording failed to start",
                "'${s.name}' could not start. Check the Log tab in the app.", false)
            sess = null
            releaseWake()
            return
        }
        pollCount = 0
        handler.removeCallbacks(ampPoll)
        handler.postDelayed(ampPoll, 1000)
    }

    private fun stopSession(reason: String, natural: Boolean) {
        val s = sess ?: return
        closeChunk()
        AppLog.log("'${s.name}' stopped: $reason")
        if (natural && s.jobId != MANUAL_ID) {
            Repo.jobs.find { it.id == s.jobId }?.let {
                if (it.isOnce) {
                    Repo.saveJob(it.copy(enabled = false))
                    AppLog.log("one-time job '${it.name}' done, turned off")
                }
            }
        }
        sess = null
        handler.removeCallbacks(ampPoll)
        releaseWake()
    }

    private fun rotate() {
        closeChunk()
        if (!openChunk()) {
            stopSession("could not open next file", natural = false)
            postAlert(this, ALERT_FAIL_ID, "Recording stopped", "Could not create the next file. See the Log tab.", false)
        }
    }

    private fun releaseWake() {
        wakeLock?.let { if (it.isHeld) it.release() }
        wakeLock = null
    }

    // ---------------------------------------------------------------- files

    @SuppressLint("MissingPermission")
    private fun openChunk(): Boolean {
        val s = sess ?: return false
        val st = Repo.settings
        val stamp = SimpleDateFormat("yyyy-MM-dd_HH-mm-ss", Locale.US).format(Date())
        val safe = s.name.replace(Regex("[^A-Za-z0-9 _-]"), "").trim().replace(' ', '_').ifEmpty { "Rec" }
        val fileName = "${safe}_$stamp.m4a"
        val out = try {
            Storage.create(this, fileName)
        } catch (e: Exception) {
            AppLog.log("cannot create file in ${Storage.folderLabel()}: $e")
            return false
        }
        val r = MediaRecorder(this)
        try {
            r.setAudioSource(Audio.SOURCES[st.source])
            r.setOutputFormat(MediaRecorder.OutputFormat.MPEG_4)
            r.setAudioEncoder(MediaRecorder.AudioEncoder.AAC)
            r.setAudioChannels(1)
            r.setAudioSamplingRate(Audio.SAMPLE_RATES[st.quality])
            r.setAudioEncodingBitRate(Audio.BIT_RATES[st.quality])
            r.setOutputFile(out.pfd.fileDescriptor)
            r.setOnErrorListener { _, what, extra ->
                AppLog.log("recorder error what=$what extra=$extra")
                handler.post { if (sess != null) rotate() }
            }
            r.prepare()
            r.start()
        } catch (e: Exception) {
            AppLog.log("recorder start failed: $e")
            try { r.release() } catch (_: Exception) {}
            Storage.discard(this, out)
            return false
        }
        s.recorder = r
        s.out = out
        s.chunkStart = System.currentTimeMillis()
        s.chunkName = fileName
        s.chunkPeak = 0
        AppLog.log("REC -> ${out.label}")
        return true
    }

    private fun closeChunk() {
        val s = sess ?: return
        val r = s.recorder ?: return
        val out = s.out ?: return
        s.recorder = null
        s.out = null
        var ok = true
        try {
            s.chunkPeak = max(s.chunkPeak, r.maxAmplitude)
            r.stop()
        } catch (e: RuntimeException) {
            ok = false
            AppLog.log("stop failed (file empty?): $e")
        }
        try { r.release() } catch (_: Exception) {}
        if (!ok) {
            Storage.discard(this, out)
            return
        }
        val size = Storage.finish(this, out)
        val dur = System.currentTimeMillis() - s.chunkStart
        Repo.addRecording(RecEntry(out.uri.toString(), s.chunkName, s.chunkStart, dur, size, s.name, s.chunkPeak))
        AppLog.log("SAVED ${s.chunkName} (${Fmt.elapsed(dur)}, ${Fmt.size(this, size)}, peak=${s.chunkPeak})")
        if (s.chunkPeak == 0 && dur > 10_000) {
            postAlert(this, ALERT_SILENT_ID, "Recording was silent",
                "${s.chunkName} captured no sound. The microphone may have been blocked.", false)
        }
    }

    // ---------------------------------------------------------------- state

    private fun disarm() {
        stopSession("scheduler turned off", natural = false)
        armed = false
        Repo.armedWanted = false
        scheduleWake(null)
        AppLog.log("scheduler OFF")
        Status.nextText = null
        publish()
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    private fun publish() {
        Status.armed = armed
        val s = sess
        Status.recName = s?.name
        Status.recJobId = s?.jobId ?: 0L
        Status.recStart = s?.startedAt ?: 0L
        Status.recEnd = s?.endsAt
        if (armed) {
            try {
                getSystemService(NotificationManager::class.java).notify(NOTIF_ID, buildNotification())
            } catch (e: Exception) {
                AppLog.log("notify failed: $e")
            }
        }
        ToggleTileService.refresh(this)
        Repo.changed()
    }

    private fun buildNotification(): Notification {
        val openApp = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE
        )
        fun svc(code: Int, action: String) = PendingIntent.getService(
            this, code, Intent(this, RecorderService::class.java).setAction(action),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val b = Notification.Builder(this, CH_STATUS)
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .setContentIntent(openApp)
            .setForegroundServiceBehavior(Notification.FOREGROUND_SERVICE_IMMEDIATE)
        val s = sess
        if (s != null) {
            b.setContentTitle("● Recording: ${s.name}")
                .setContentText(s.endsAt?.let { "Until ${Fmt.clock(this, it)}" } ?: "Until you stop it")
                .setUsesChronometer(true)
                .setWhen(s.startedAt)
                .setShowWhen(true)
                .addAction(Notification.Action.Builder(null, "Stop recording", svc(3, ACTION_REC_STOP)).build())
        } else {
            b.setContentTitle("Scheduler on")
                .setContentText(Status.nextText?.let { "Next: $it" } ?: "No upcoming jobs")
                .setShowWhen(false)
        }
        b.addAction(Notification.Action.Builder(null, "Turn off", svc(4, ACTION_DISARM)).build())
        return b.build()
    }

    override fun onTaskRemoved(rootIntent: Intent?) {
        AppLog.log("app swiped away from recents (scheduler keeps running)")
    }

    override fun onDestroy() {
        if (sess != null) stopSession("service destroyed", natural = false)
        handler.removeCallbacksAndMessages(null)
        if (armed) AppLog.log("service destroyed while ON")
        armed = false
        Status.armed = false
        Status.recName = null
        Status.nextText = null
        ToggleTileService.refresh(this)
        Repo.changed()
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null
}
