package com.example.audiodumper

import org.json.JSONObject
import java.util.Calendar

/**
 * A scheduled recording job.
 * days: bitmask Mon=bit0 .. Sun=bit6. 0 = run once (next occurrence), then auto-disable.
 */
data class Job(
    val id: Long,
    val name: String,
    val hour: Int,
    val minute: Int,
    val durationMin: Int,
    val days: Int,
    val splitMin: Int,
    val enabled: Boolean,
) {
    val isOnce: Boolean get() = days == 0

    fun runsOn(c: Calendar): Boolean = days == 0 || (days and (1 shl dayIndex(c))) != 0

    /** Returns [start, end) of the window that contains time t, or null. */
    fun windowAt(t: Long): LongArray? {
        for (off in 0 downTo -1) {
            val c = startOnDay(t, off)
            if (!runsOn(c)) continue
            val s = c.timeInMillis
            val e = s + durationMin * 60_000L
            if (t >= s && t < e) return longArrayOf(s, e)
        }
        return null
    }

    /** Next start time strictly after t, or null. */
    fun nextStart(t: Long): Long? {
        for (off in 0..7) {
            val c = startOnDay(t, off)
            if (c.timeInMillis > t && runsOn(c)) return c.timeInMillis
        }
        return null
    }

    private fun startOnDay(t: Long, off: Int): Calendar = Calendar.getInstance().apply {
        timeInMillis = t
        add(Calendar.DAY_OF_YEAR, off)
        set(Calendar.HOUR_OF_DAY, hour)
        set(Calendar.MINUTE, minute)
        set(Calendar.SECOND, 0)
        set(Calendar.MILLISECOND, 0)
    }

    fun toJson(): JSONObject = JSONObject()
        .put("id", id).put("name", name).put("h", hour).put("m", minute)
        .put("dur", durationMin).put("days", days).put("split", splitMin).put("en", enabled)

    companion object {
        const val EVERY_DAY = 127
        const val WEEKDAYS = 31
        const val WEEKENDS = 96
        val DAY_SHORT = arrayOf("Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun")
        val DAY_LETTER = arrayOf("M", "T", "W", "T", "F", "S", "S")

        /** Mon=0 .. Sun=6 */
        fun dayIndex(c: Calendar): Int = (c.get(Calendar.DAY_OF_WEEK) + 5) % 7

        fun fromJson(o: JSONObject) = Job(
            id = o.getLong("id"),
            name = o.optString("name", "Job"),
            hour = o.getInt("h"),
            minute = o.getInt("m"),
            durationMin = o.getInt("dur"),
            days = o.optInt("days", EVERY_DAY),
            splitMin = o.optInt("split", 0),
            enabled = o.optBoolean("en", true),
        )
    }
}

/** One saved audio file. */
data class RecEntry(
    val uri: String,
    val name: String,
    val start: Long,
    val durMs: Long,
    val size: Long,
    val job: String,
    val peak: Int,
) {
    fun toJson(): JSONObject = JSONObject()
        .put("uri", uri).put("name", name).put("start", start).put("dur", durMs)
        .put("size", size).put("job", job).put("peak", peak)

    companion object {
        fun fromJson(o: JSONObject) = RecEntry(
            uri = o.getString("uri"),
            name = o.optString("name"),
            start = o.optLong("start"),
            durMs = o.optLong("dur"),
            size = o.optLong("size"),
            job = o.optString("job"),
            peak = o.optInt("peak", -1),
        )
    }
}

data class Settings(
    val folderUri: String? = null,
    val folderLabel: String? = null,
    val quality: Int = 1, // 0 low, 1 standard, 2 high
    val source: Int = 0,  // index into Audio.SOURCES
)

object Audio {
    val QUALITY_NAMES = arrayOf("Low", "Standard", "High")
    val QUALITY_DESC = arrayOf("64 kbps · ~29 MB/hour", "128 kbps · ~58 MB/hour", "256 kbps · ~115 MB/hour")
    val SAMPLE_RATES = intArrayOf(22_050, 44_100, 48_000)
    val BIT_RATES = intArrayOf(64_000, 128_000, 256_000)

    val SOURCE_NAMES = arrayOf("Default mic", "Voice recognition", "Camcorder")
    val SOURCE_DESC = arrayOf(
        "Standard microphone with the phone's processing.",
        "Less processing (no auto gain). Good for quiet rooms.",
        "Uses the mic next to the camera; tuned for video.",
    )
    val SOURCES = intArrayOf(
        android.media.MediaRecorder.AudioSource.MIC,
        android.media.MediaRecorder.AudioSource.VOICE_RECOGNITION,
        android.media.MediaRecorder.AudioSource.CAMCORDER,
    )
}

/** Live state published by RecorderService for the UI, tile and notification. */
object Status {
    @Volatile var armed = false
    @Volatile var recName: String? = null
    @Volatile var recJobId = 0L
    @Volatile var recStart = 0L
    @Volatile var recEnd: Long? = null
    @Volatile var nextText: String? = null
}
