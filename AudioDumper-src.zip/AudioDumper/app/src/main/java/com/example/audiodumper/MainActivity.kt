package com.example.audiodumper

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Typeface
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.PowerManager
import android.provider.Settings
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import java.io.File

/**
 * Control panel + live log viewer. Also the target of the Quick Settings tile
 * and the launcher shortcuts (long-press app icon -> Start / Stop).
 * Starting from this Activity (visible on screen) is what grants the service mic access.
 */
class MainActivity : Activity() {

    companion object {
        const val ACTION_START = "com.example.audiodumper.START"
        private const val REQ_PERMS = 1
        private const val LOG_LINES = 300
    }

    private lateinit var status: TextView
    private lateinit var logView: TextView
    private lateinit var logScroll: ScrollView
    private val ui = Handler(Looper.getMainLooper())
    private var pendingStart = false

    private val logFile: File get() = File(getExternalFilesDir(null), "service.log")

    private val autoRefresh = object : Runnable {
        override fun run() {
            refreshStatus(); refreshLog()
            ui.postDelayed(this, 2000)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        fun row(vararg buttons: Button) = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            buttons.forEach { addView(it, LinearLayout.LayoutParams(0, -2, 1f)) }
        }
        fun btn(label: String, onClick: () -> Unit) =
            Button(this).apply { text = label; setOnClickListener { onClick() } }

        status = TextView(this).apply { textSize = 16f }
        logView = TextView(this).apply {
            typeface = Typeface.MONOSPACE
            textSize = 11f
            setTextIsSelectable(true)
        }
        logScroll = ScrollView(this).apply { addView(logView) }

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(32, 96, 32, 32)
            addView(status)
            addView(row(btn("Start") { startRecorder() }, btn("Stop") { stopRecorder() }))
            addView(row(btn("Share log") { shareLog() }, btn("Clear log") { clearLog() }))
            addView(btn("Disable battery optimization") { askIgnoreBatteryOptimizations() })
            addView(logScroll, LinearLayout.LayoutParams(-1, 0, 1f))
        }
        setContentView(root)

        handleIntent(intent)
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        handleIntent(intent)
    }

    override fun onResume() {
        super.onResume()
        ui.post(autoRefresh)
    }

    override fun onPause() {
        ui.removeCallbacks(autoRefresh)
        super.onPause()
    }

    private fun handleIntent(intent: Intent?) {
        when (intent?.action) {
            ACTION_START -> startRecorder()
            RecorderService.ACTION_STOP -> stopRecorder()
        }
    }

    private fun startRecorder() {
        val missing = buildList {
            if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED)
                add(Manifest.permission.RECORD_AUDIO)
            if (checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED)
                add(Manifest.permission.POST_NOTIFICATIONS)
        }
        if (missing.isNotEmpty()) {
            pendingStart = true
            requestPermissions(missing.toTypedArray(), REQ_PERMS)
            return
        }
        startForegroundService(Intent(this, RecorderService::class.java))
    }

    private fun stopRecorder() {
        stopService(Intent(this, RecorderService::class.java))
    }

    override fun onRequestPermissionsResult(code: Int, perms: Array<out String>, results: IntArray) {
        super.onRequestPermissionsResult(code, perms, results)
        if (code != REQ_PERMS || !pendingStart) return
        pendingStart = false
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) {
            startRecorder()
        } else {
            Toast.makeText(this, "Microphone permission is required", Toast.LENGTH_LONG).show()
        }
    }

    private fun readTail(): String = try {
        if (logFile.exists()) logFile.readLines().takeLast(LOG_LINES).joinToString("\n")
        else "(no log yet — press Start)"
    } catch (e: Exception) { "log read error: $e" }

    private fun refreshLog() {
        val atBottom = !logScroll.canScrollVertically(1)
        logView.text = readTail()
        if (atBottom) logScroll.post { logScroll.fullScroll(ScrollView.FOCUS_DOWN) }
    }

    /** Share via WhatsApp/Gmail/Drive etc. — no adb needed. */
    private fun shareLog() {
        val send = Intent(Intent.ACTION_SEND).apply {
            type = "text/plain"
            putExtra(Intent.EXTRA_SUBJECT, "AudioDumper log")
            putExtra(Intent.EXTRA_TEXT, readTail())
        }
        startActivity(Intent.createChooser(send, "Share log"))
    }

    private fun clearLog() {
        logFile.delete()
        File(logFile.path + ".1").delete()
        refreshLog()
    }

    private fun askIgnoreBatteryOptimizations() {
        val pm = getSystemService(PowerManager::class.java)
        if (pm.isIgnoringBatteryOptimizations(packageName)) {
            Toast.makeText(this, "Already unrestricted", Toast.LENGTH_SHORT).show()
            return
        }
        startActivity(
            Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, Uri.parse("package:$packageName"))
        )
    }

    private fun refreshStatus() {
        val battery = getSystemService(PowerManager::class.java).isIgnoringBatteryOptimizations(packageName)
        status.text = "Service: " + (if (RecorderService.isRunning) "RUNNING ●" else "stopped") +
            "    Battery unrestricted: " + (if (battery) "yes" else "NO")
    }
}
