package com.example.audiodumper

import android.Manifest
import android.app.Activity
import android.app.AlarmManager
import android.app.AlertDialog
import android.app.TimePickerDialog
import android.content.Intent
import android.content.pm.PackageManager
import android.content.res.ColorStateList
import android.graphics.Color
import android.graphics.Typeface
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.PowerManager
import android.provider.Settings as SysSettings
import android.text.format.DateFormat
import android.view.Gravity
import android.view.View
import android.view.Window
import android.view.WindowInsets
import android.view.WindowInsetsController
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.NumberPicker
import android.widget.ProgressBar
import android.widget.ScrollView
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast
import com.example.audiodumper.UiKit.Companion.MATCH
import com.example.audiodumper.UiKit.Companion.WRAP

class MainActivity : Activity() {

    companion object {
        private const val REQ_PERMS = 1
        private const val REQ_FOLDER = 2
        private val TABS = arrayOf("⏰\nJobs", "🎙\nRecordings", "📄\nLog", "⚙\nSettings")
    }

    private lateinit var p: Pal
    private lateinit var k: UiKit
    private lateinit var statusBox: LinearLayout
    private lateinit var content: LinearLayout
    private lateinit var scroll: ScrollView
    private lateinit var nav: LinearLayout
    private var tab = 0
    private var elapsedView: TextView? = null
    private var progressView: ProgressBar? = null
    private var logView: TextView? = null
    private var tick = 0
    private var pending: (() -> Unit)? = null
    private val ui = Handler(Looper.getMainLooper())
    private val onChange: () -> Unit = { render() }

    private val ticker = object : Runnable {
        override fun run() {
            tick++
            updateLive()
            if (tab == 2 && tick % 2 == 0) refreshLog()
            ui.postDelayed(this, 1000)
        }
    }

    // ================================================================ lifecycle

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        requestWindowFeature(Window.FEATURE_NO_TITLE)
        p = Pal(this)
        k = UiKit(this, p)
        tab = savedInstanceState?.getInt("tab") ?: 0

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(p.bg)
        }
        val header = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(k.dp(22), k.dp(14), k.dp(22), k.dp(10))
            addView(k.text("AudioDumper", 26f, p.text, bold = true))
            addView(k.text("Scheduled audio recorder", 13f, p.sub))
        }
        statusBox = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(k.dp(14), 0, k.dp(14), 0)
        }
        content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(k.dp(14), k.dp(4), k.dp(14), k.dp(24))
        }
        scroll = ScrollView(this).apply {
            isFillViewport = true
            addView(content)
        }
        nav = k.row().apply {
            setPadding(k.dp(8), k.dp(6), k.dp(8), k.dp(6))
            setBackgroundColor(p.card)
        }
        root.addView(header)
        root.addView(statusBox)
        root.addView(scroll, LinearLayout.LayoutParams(MATCH, 0, 1f))
        root.addView(nav, LinearLayout.LayoutParams(MATCH, WRAP))
        setContentView(root)

        // Edge-to-edge (required look on Android 15) with proper padding for bars.
        window.setDecorFitsSystemWindows(false)
        root.setOnApplyWindowInsetsListener { v, ins ->
            val b = ins.getInsets(WindowInsets.Type.systemBars() or WindowInsets.Type.ime())
            v.setPadding(b.left, b.top, b.right, b.bottom)
            WindowInsets.CONSUMED
        }
        @Suppress("DEPRECATION")
        window.statusBarColor = Color.TRANSPARENT
        @Suppress("DEPRECATION")
        window.navigationBarColor = p.card
        val lightBars = WindowInsetsController.APPEARANCE_LIGHT_STATUS_BARS or
            WindowInsetsController.APPEARANCE_LIGHT_NAVIGATION_BARS
        window.insetsController?.setSystemBarsAppearance(if (p.night) 0 else lightBars, lightBars)

        RecorderService.ensureChannels(this)
        handleIntent(intent)
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        handleIntent(intent)
    }

    override fun onSaveInstanceState(outState: Bundle) {
        super.onSaveInstanceState(outState)
        outState.putInt("tab", tab)
    }

    override fun onResume() {
        super.onResume()
        Repo.addListener(onChange)
        render()
        ui.post(ticker)
    }

    override fun onPause() {
        Repo.removeListener(onChange)
        ui.removeCallbacks(ticker)
        super.onPause()
    }

    private fun handleIntent(i: Intent?) {
        when (i?.action) {
            RecorderService.ACTION_ARM -> armScheduler()
            RecorderService.ACTION_DISARM -> RecorderService.send(this, RecorderService.ACTION_DISARM)
        }
    }

    // ================================================================ actions

    private fun withPermissions(block: () -> Unit) {
        val missing = ArrayList<String>()
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED)
            missing.add(Manifest.permission.RECORD_AUDIO)
        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED)
            missing.add(Manifest.permission.POST_NOTIFICATIONS)
        if (missing.isEmpty()) {
            block()
        } else {
            pending = block
            requestPermissions(missing.toTypedArray(), REQ_PERMS)
        }
    }

    override fun onRequestPermissionsResult(code: Int, perms: Array<out String>, results: IntArray) {
        super.onRequestPermissionsResult(code, perms, results)
        if (code != REQ_PERMS) return
        val block = pending
        pending = null
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) {
            block?.invoke()
        } else {
            toast("Microphone permission is required to record")
        }
        render()
    }

    private fun armScheduler() = withPermissions {
        try {
            RecorderService.startFromForeground(this, RecorderService.ACTION_ARM)
        } catch (e: Exception) {
            AppLog.log("arm failed: $e")
            toast("Could not start: $e")
        }
    }

    private fun recordNow(minutes: Int) = withPermissions {
        try {
            RecorderService.startFromForeground(this, RecorderService.ACTION_REC_NOW, minutes)
        } catch (e: Exception) {
            AppLog.log("record now failed: $e")
            toast("Could not start: $e")
        }
    }

    private fun recordNowDialog() {
        val labels = arrayOf("15 minutes", "30 minutes", "1 hour", "2 hours", "Until I stop it")
        val mins = intArrayOf(15, 30, 60, 120, 0)
        AlertDialog.Builder(this)
            .setTitle("Record now")
            .setItems(labels) { _, which -> recordNow(mins[which]) }
            .show()
    }

    /** After jobs change: wake the scheduler, or turn it on if it's off. */
    private fun jobsChanged(armIfOff: Boolean) {
        if (Status.armed) RecorderService.send(this, RecorderService.ACTION_CHECK)
        else if (armIfOff && Repo.jobs.any { it.enabled }) armScheduler()
    }

    private fun batteryOk(): Boolean =
        getSystemService(PowerManager::class.java).isIgnoringBatteryOptimizations(packageName)

    private fun askBattery() {
        try {
            startActivity(
                Intent(SysSettings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, Uri.parse("package:$packageName"))
            )
        } catch (e: Exception) {
            openAppSettings()
        }
    }

    private fun openAppSettings() {
        startActivity(Intent(SysSettings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$packageName")))
    }

    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_LONG).show()

    // ================================================================ rendering

    private fun render() {
        buildStatus()
        buildNav()
        content.removeAllViews()
        logView = null
        when (tab) {
            0 -> jobsTab()
            1 -> recordingsTab()
            2 -> logTab()
            else -> settingsTab()
        }
    }

    private fun buildNav() {
        nav.removeAllViews()
        TABS.forEachIndexed { i, label ->
            val t = k.text(label, 12f, if (i == tab) p.accent else p.sub, bold = i == tab).apply {
                gravity = Gravity.CENTER
                setPadding(0, k.dp(6), 0, k.dp(6))
            }
            k.clickable(t, if (i == tab) p.accentSoft else p.card, 18) {
                if (tab != i) {
                    tab = i
                    render()
                    scroll.scrollTo(0, 0)
                }
            }
            nav.addView(k.place(t, w = 0, weight = 1f, start = 4, end = 4))
        }
    }

    private fun buildStatus() {
        statusBox.removeAllViews()
        val c = k.card()
        val recording = Status.recName != null
        val armed = Status.armed
        val dotColor = when { recording -> p.red; armed -> p.green; else -> p.sub }
        val title = when { recording -> "Recording"; armed -> "Scheduler on"; else -> "Scheduler off" }

        val top = k.row()
        top.addView(k.text("●", 18f, dotColor))
        top.addView(k.place(k.text(title, 19f, p.text, bold = true), w = 0, weight = 1f, start = 8))
        val sw = Switch(this)
        sw.isChecked = armed
        sw.setOnCheckedChangeListener { _, on ->
            if (on) armScheduler() else RecorderService.send(this, RecorderService.ACTION_DISARM)
        }
        top.addView(sw)
        c.addView(top)

        if (recording) {
            c.addView(k.place(k.text(Status.recName ?: "", 16f, p.text, bold = true), top = 8))
            val end = Status.recEnd
            val line = "Started ${Fmt.clock(this, Status.recStart)}  ·  " +
                (if (end != null) "ends ${Fmt.clock(this, end)}" else "until you stop it")
            c.addView(k.text(line, 13f, p.sub))
            val ev = k.text("00:00", 34f, p.red, bold = true).apply { fontFeatureSettings = "tnum" }
            elapsedView = ev
            c.addView(k.place(ev, top = 4))
            if (end != null) {
                val pb = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply {
                    max = 1000
                    progressTintList = ColorStateList.valueOf(p.red)
                }
                progressView = pb
                c.addView(k.place(pb, top = 2))
            } else {
                progressView = null
            }
            c.addView(k.place(k.button("■   Stop recording", Kind.DANGER) {
                RecorderService.send(this, RecorderService.ACTION_REC_STOP)
            }, top = 12))
        } else {
            elapsedView = null
            progressView = null
            val msg = if (armed) {
                Status.nextText?.let { "Next: $it" } ?: "No upcoming jobs. Add one below."
            } else {
                "Turn the scheduler on and your jobs will record automatically, even with the screen locked."
            }
            c.addView(k.place(k.text(msg, 14f, p.sub), top = 6))
            c.addView(k.place(k.button("●   Record now", Kind.TONAL) { recordNowDialog() }, top = 12))
        }
        if (!batteryOk()) {
            val w = k.text("⚠  Battery optimization is on, so jobs can be delayed or killed. Tap to fix.", 13f, p.warn)
            w.setOnClickListener { askBattery() }
            c.addView(k.place(w, top = 12))
        }
        statusBox.addView(c)
        updateLive()
    }

    private fun updateLive() {
        if (Status.recName == null) return
        val now = System.currentTimeMillis()
        elapsedView?.text = Fmt.elapsed(now - Status.recStart)
        val end = Status.recEnd
        val pb = progressView
        if (end != null && pb != null && end > Status.recStart) {
            pb.progress = (((now - Status.recStart) * 1000) / (end - Status.recStart)).toInt().coerceIn(0, 1000)
        }
    }

    // ================================================================ Jobs tab

    private fun jobsTab() {
        content.addView(k.place(k.button("+   New job", Kind.FILLED) { openEditor(null) }, w = WRAP, top = 4, bottom = 12))
        val jobs = Repo.jobs.sortedWith(compareBy({ it.hour }, { it.minute }))
        if (jobs.isEmpty()) {
            val c = k.card()
            c.addView(k.text("No jobs yet", 17f, p.text, bold = true))
            c.addView(k.place(k.text(
                "Create a job such as “Every day at 09:00 for 1 hour”. " +
                    "Recording starts and stops on its own, and the files are saved to your folder.",
                14f, p.sub), top = 4))
            content.addView(c)
            return
        }
        val now = System.currentTimeMillis()
        for (j in jobs) {
            val c = k.card()
            val top = k.row()
            top.addView(k.place(k.text(j.name, 17f, p.text, bold = true), w = 0, weight = 1f))
            val sw = Switch(this)
            sw.isChecked = j.enabled
            sw.setOnCheckedChangeListener { _, on ->
                Repo.saveJob(j.copy(enabled = on))
                jobsChanged(armIfOff = on)
            }
            top.addView(sw)
            c.addView(top)

            val endMin = j.hour * 60 + j.minute + j.durationMin
            val endTxt = Fmt.hm(this, (endMin / 60) % 24, endMin % 60) + if (endMin >= 1440) " (+1 day)" else ""
            c.addView(k.place(k.text("${Fmt.hm(this, j.hour, j.minute)}  →  $endTxt   ·   ${Fmt.dur(j.durationMin)}", 15f), top = 2))
            var info = Fmt.daysText(j.days)
            if (j.splitMin > 0) info += "   ·   new file every ${Fmt.dur(j.splitMin)}"
            c.addView(k.text(info, 13f, p.sub))

            val (stxt, scol) = when {
                Status.recName != null && Status.recJobId == j.id -> "●  Recording now" to p.red
                !j.enabled -> "Off" to p.sub
                !Status.armed -> "Waiting: turn the scheduler on" to p.warn
                else -> (j.nextStart(now)?.let { "Next run: ${Fmt.whenText(this, it)}" } ?: "No upcoming run") to p.accent
            }
            c.addView(k.place(k.text(stxt, 13f, scol, bold = true), top = 8))
            k.clickable(c, p.card, 22) { openEditor(j) }
            content.addView(c)
        }
        content.addView(k.text("Tap a job to edit or delete it.", 12f, p.sub).apply { gravity = Gravity.CENTER })
    }

    private fun openEditor(existing: Job?) {
        var h = existing?.hour ?: 9
        var m = existing?.minute ?: 0
        var days = existing?.days ?: Job.EVERY_DAY
        var split = existing?.splitMin ?: 30
        val dur0 = existing?.durationMin ?: 60

        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(k.dp(22), k.dp(6), k.dp(22), k.dp(6))
        }
        val name = EditText(this).apply {
            setText(existing?.name ?: "Job ${Repo.jobs.size + 1}")
            hint = "Job name"
            setSingleLine()
            setSelectAllOnFocus(true)
        }
        box.addView(k.section("Name"))
        box.addView(name)

        box.addView(k.section("Start time"))
        val timeBtn = k.text("", 30f, p.accent, bold = true).apply {
            setPadding(k.dp(16), k.dp(6), k.dp(16), k.dp(6))
        }
        box.addView(k.place(timeBtn, w = WRAP))

        box.addView(k.section("Duration"))
        val hp = NumberPicker(this).apply { minValue = 0; maxValue = 23; value = dur0 / 60 }
        val mp = NumberPicker(this).apply { minValue = 0; maxValue = 59; value = dur0 % 60 }
        val pickRow = k.row().apply {
            addView(hp)
            addView(k.place(k.text("h", 16f, p.sub), w = WRAP, start = 6, end = 18))
            addView(mp)
            addView(k.place(k.text("min", 16f, p.sub), w = WRAP, start = 6))
        }
        box.addView(pickRow)
        val endsTxt = k.text("", 14f, p.sub)
        box.addView(k.place(endsTxt, top = 4))

        lateinit var refresh: () -> Unit
        val quick = listOf(15 to "15 min", 30 to "30 min", 60 to "1 h", 120 to "2 h", 180 to "3 h", 480 to "8 h")
        box.addView(k.place(k.chipRow(quick.map { (v, label) ->
            k.chip(label) { hp.value = v / 60; mp.value = v % 60; refresh() }
        }), top = 8))

        box.addView(k.section("Repeat"))
        val dayViews = (0..6).map { i ->
            k.text(Job.DAY_LETTER[i], 14f, p.text, bold = true).apply {
                gravity = Gravity.CENTER
                setOnClickListener { days = days xor (1 shl i); refresh() }
            }
        }
        val dayRow = k.row()
        dayViews.forEach { dayRow.addView(k.place(it, w = k.dp(38), h = k.dp(38), end = 4)) }
        box.addView(dayRow)
        val presets = listOf(Job.EVERY_DAY to "Every day", Job.WEEKDAYS to "Weekdays", Job.WEEKENDS to "Weekends", 0 to "Once")
        val presetViews = presets.map { (v, label) -> v to k.chip(label) { days = v; refresh() } }
        box.addView(k.place(k.chipRow(presetViews.map { it.second }), top = 10))
        val repeatTxt = k.text("", 13f, p.sub)
        box.addView(k.place(repeatTxt, top = 6))

        box.addView(k.section("Save as separate files"))
        val splits = listOf(0 to "One file", 10 to "Every 10 min", 15 to "15 min", 30 to "30 min", 60 to "1 hour")
        val splitViews = splits.map { (v, label) -> v to k.chip(label) { split = v; refresh() } }
        box.addView(k.chipRow(splitViews.map { it.second }))
        box.addView(k.place(k.text(
            "Splitting keeps files small, and if the phone restarts mid-recording you only lose the current part.",
            12f, p.sub), top = 6, bottom = 8))

        refresh = {
            timeBtn.text = Fmt.hm(this, h, m)
            val dur = hp.value * 60 + mp.value
            val endMin = h * 60 + m + dur
            endsTxt.text = if (dur == 0) "Set a duration of at least 1 minute" else
                "Records ${Fmt.dur(dur)}, ends at ${Fmt.hm(this, (endMin / 60) % 24, endMin % 60)}" +
                    (if (endMin >= 1440) " the next day" else "")
            dayViews.forEachIndexed { i, tv ->
                val on = days and (1 shl i) != 0
                tv.background = k.rippleBg(if (on) p.accent else p.chip, 19)
                tv.setTextColor(if (on) p.onAccent else p.text)
            }
            presetViews.forEach { (v, tv) -> k.styleChip(tv, days == v) }
            repeatTxt.text = if (days == 0) "Runs once at the next ${Fmt.hm(this, h, m)}, then switches itself off."
            else "Repeats: ${Fmt.daysText(days)}"
            splitViews.forEach { (v, tv) -> k.styleChip(tv, split == v) }
        }
        timeBtn.background = k.rippleBg(p.accentSoft, 16)
        timeBtn.setOnClickListener {
            TimePickerDialog(this, { _, hh, mm -> h = hh; m = mm; refresh() }, h, m,
                DateFormat.is24HourFormat(this)).show()
        }
        hp.setOnValueChangedListener { _, _, _ -> refresh() }
        mp.setOnValueChangedListener { _, _, _ -> refresh() }
        refresh()

        val builder = AlertDialog.Builder(this)
            .setTitle(if (existing == null) "New job" else "Edit job")
            .setView(ScrollView(this).apply { addView(box) })
            .setPositiveButton("Save", null)
            .setNegativeButton("Cancel", null)
        if (existing != null) builder.setNeutralButton("Delete", null)
        val dlg = builder.create()
        dlg.setOnShowListener {
            dlg.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener {
                val dur = hp.value * 60 + mp.value
                if (dur < 1) {
                    toast("Set a duration of at least 1 minute")
                    return@setOnClickListener
                }
                val job = Job(
                    id = existing?.id ?: System.currentTimeMillis(),
                    name = name.text.toString().trim().ifEmpty { "Job" },
                    hour = h, minute = m, durationMin = dur, days = days,
                    splitMin = if (split >= dur) 0 else split,
                    enabled = true,
                )
                Repo.saveJob(job)
                AppLog.log("job saved: ${job.name} ${Fmt.hm(this, h, m)} ${Fmt.dur(dur)} ${Fmt.daysText(days)}")
                dlg.dismiss()
                jobsChanged(armIfOff = true)
            }
            dlg.getButton(AlertDialog.BUTTON_NEUTRAL)?.setOnClickListener {
                AlertDialog.Builder(this)
                    .setTitle("Delete “${existing?.name}”?")
                    .setMessage("Recordings already saved are kept.")
                    .setPositiveButton("Delete") { _, _ ->
                        existing?.let { Repo.deleteJob(it.id); AppLog.log("job deleted: ${it.name}") }
                        dlg.dismiss()
                        jobsChanged(armIfOff = false)
                    }
                    .setNegativeButton("Cancel", null)
                    .show()
            }
        }
        dlg.show()
    }

    // ================================================================ Recordings tab

    private fun recordingsTab() {
        val f = k.card()
        f.addView(k.text("Save location", 16f, p.text, bold = true))
        f.addView(k.place(k.text(Storage.folderLabel(), 14f, p.accent), top = 4))
        val r = k.row()
        r.addView(k.place(k.button("Change folder", Kind.TONAL) { pickFolder() }, w = WRAP, end = 8))
        if (Repo.settings.folderUri != null) {
            r.addView(k.place(k.button("Use default", Kind.PLAIN) {
                Repo.updateSettings { it.copy(folderUri = null, folderLabel = null) }
                AppLog.log("save folder -> default (${Storage.folderLabel()})")
            }, w = WRAP))
        }
        f.addView(k.place(r, top = 12))
        content.addView(f)

        val recs = Repo.recordings
        content.addView(k.place(k.section("Recent recordings (${recs.size})"), bottom = 2))
        if (recs.isEmpty()) {
            val c = k.card()
            c.addView(k.text("Nothing recorded yet.", 14f, p.sub))
            content.addView(c)
            return
        }
        for (e in recs.take(150)) {
            val c = k.card()
            c.addView(k.text(e.name, 15f, p.text, bold = true).apply {
                setSingleLine()
                ellipsize = android.text.TextUtils.TruncateAt.MIDDLE
            })
            val sizeTxt = if (e.size >= 0) "   ·   ${Fmt.size(this, e.size)}" else ""
            c.addView(k.text("${Fmt.dateTime(this, e.start)}   ·   ${Fmt.elapsed(e.durMs)}$sizeTxt", 13f, p.sub))
            c.addView(k.text(e.job, 13f, p.sub))
            if (e.peak == 0) c.addView(k.place(k.text("⚠  No sound captured", 13f, p.red, bold = true), top = 4))
            k.clickable(c, p.card, 22) { play(e) }
            c.setOnLongClickListener { recordingMenu(e); true }
            content.addView(c)
        }
        content.addView(k.text("Tap to play · long-press for share / delete", 12f, p.sub).apply { gravity = Gravity.CENTER })
    }

    private fun pickFolder() {
        val i = Intent(Intent.ACTION_OPEN_DOCUMENT_TREE).addFlags(
            Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION or
                Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION
        )
        try {
            @Suppress("DEPRECATION")
            startActivityForResult(i, REQ_FOLDER)
        } catch (e: Exception) {
            toast("No folder picker available")
        }
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        @Suppress("DEPRECATION")
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode != REQ_FOLDER || resultCode != RESULT_OK) return
        val uri = data?.data ?: return
        try {
            contentResolver.takePersistableUriPermission(
                uri, Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION
            )
        } catch (e: Exception) {
            AppLog.log("could not keep folder permission: $e")
            toast("Could not get permanent access to that folder")
            return
        }
        val label = Storage.labelForTree(uri)
        Repo.updateSettings { it.copy(folderUri = uri.toString(), folderLabel = label) }
        AppLog.log("save folder -> $label")
        toast("Recordings will be saved to $label")
    }

    private fun play(e: RecEntry) {
        val i = Intent(Intent.ACTION_VIEW)
            .setDataAndType(Uri.parse(e.uri), "audio/*")
            .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        try {
            startActivity(i)
        } catch (ex: Exception) {
            toast("No app found to play this file")
        }
    }

    private fun share(e: RecEntry) {
        val i = Intent(Intent.ACTION_SEND)
            .setType("audio/mp4")
            .putExtra(Intent.EXTRA_STREAM, Uri.parse(e.uri))
            .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        startActivity(Intent.createChooser(i, "Share recording"))
    }

    private fun recordingMenu(e: RecEntry) {
        AlertDialog.Builder(this)
            .setTitle(e.name)
            .setItems(arrayOf("Play", "Share", "Delete file", "Remove from list only")) { _, which ->
                when (which) {
                    0 -> play(e)
                    1 -> share(e)
                    2 -> AlertDialog.Builder(this)
                        .setTitle("Delete this recording?")
                        .setMessage(e.name)
                        .setPositiveButton("Delete") { _, _ ->
                            val ok = Storage.delete(this, Uri.parse(e.uri))
                            Repo.removeRecording(e.uri)
                            if (!ok) toast("Couldn't delete the file (maybe already gone). Removed from list.")
                        }
                        .setNegativeButton("Cancel", null)
                        .show()
                    3 -> Repo.removeRecording(e.uri)
                }
            }
            .show()
    }

    // ================================================================ Log tab

    private fun logTab() {
        val r = k.row()
        r.addView(k.place(k.button("Share log", Kind.TONAL) {
            val i = Intent(Intent.ACTION_SEND).setType("text/plain")
                .putExtra(Intent.EXTRA_SUBJECT, "AudioDumper log")
                .putExtra(Intent.EXTRA_TEXT, AppLog.tail(400))
            startActivity(Intent.createChooser(i, "Share log"))
        }, w = WRAP, end = 8))
        r.addView(k.place(k.button("Clear", Kind.PLAIN) {
            AppLog.clear()
            refreshLog()
        }, w = WRAP))
        content.addView(k.place(r, top = 4, bottom = 12))
        val c = k.card()
        val lv = k.text("", 11f, p.text).apply {
            typeface = Typeface.MONOSPACE
            setTextIsSelectable(true)
        }
        logView = lv
        c.addView(lv)
        content.addView(c)
        refreshLog()
        scroll.post { scroll.fullScroll(View.FOCUS_DOWN) }
    }

    private fun refreshLog() {
        val lv = logView ?: return
        val atBottom = !scroll.canScrollVertically(1)
        lv.text = AppLog.tail(400)
        if (atBottom) scroll.post { scroll.fullScroll(View.FOCUS_DOWN) }
    }

    // ================================================================ Settings tab

    private fun settingsTab() {
        val st = Repo.settings

        val q = k.card()
        q.addView(k.text("Recording quality", 16f, p.text, bold = true))
        q.addView(k.place(k.chipRow(Audio.QUALITY_NAMES.mapIndexed { i, n ->
            k.chip(n) { Repo.updateSettings { it.copy(quality = i) } }.also { k.styleChip(it, st.quality == i) }
        }), top = 10))
        q.addView(k.place(k.text("AAC .m4a, mono · ${Audio.QUALITY_DESC[st.quality]}", 13f, p.sub), top = 8))
        content.addView(q)

        val s = k.card()
        s.addView(k.text("Microphone", 16f, p.text, bold = true))
        s.addView(k.place(k.chipRow(Audio.SOURCE_NAMES.mapIndexed { i, n ->
            k.chip(n) { Repo.updateSettings { it.copy(source = i) } }.also { k.styleChip(it, st.source == i) }
        }), top = 10))
        s.addView(k.place(k.text(Audio.SOURCE_DESC[st.source], 13f, p.sub), top = 8))
        s.addView(k.text("Changes apply to the next file.", 12f, p.sub))
        content.addView(s)

        val c = k.card()
        c.addView(k.text("Reliability checks", 16f, p.text, bold = true))
        val mic = checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED
        checkRow(c, "Microphone permission", mic) { withPermissions { } }
        if (Build.VERSION.SDK_INT >= 33) {
            val notif = checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED
            checkRow(c, "Notifications", notif) { withPermissions { } }
        }
        checkRow(c, "Battery: unrestricted", batteryOk()) { askBattery() }
        val alarms = getSystemService(AlarmManager::class.java).canScheduleExactAlarms()
        checkRow(c, "Exact alarms (on-time start)", alarms) {
            try {
                startActivity(Intent(SysSettings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM, Uri.parse("package:$packageName")))
            } catch (e: Exception) {
                openAppSettings()
            }
        }
        content.addView(c)

        val t = k.card()
        t.addView(k.text("Samsung tips", 16f, p.text, bold = true))
        t.addView(k.place(k.text(
            "• Settings → Battery → Background usage limits: AudioDumper must NOT be in “Sleeping apps” or “Deep sleeping apps”. Add it to “Never sleeping apps”.\n" +
                "• App info → Battery → choose “Unrestricted”.\n" +
                "• Swiping the app away is fine. “Force stop” turns the scheduler off.\n" +
                "• After a restart or app update, tap the notification (or open the app) to turn the scheduler back on. Android doesn't allow the microphone to start by itself after boot.",
            13f, p.sub), top = 6))
        t.addView(k.place(k.button("Open app info", Kind.PLAIN) { openAppSettings() }, w = WRAP, top = 12))
        content.addView(t)

        val a = k.card()
        a.addView(k.text("How it works", 16f, p.text, bold = true))
        a.addView(k.place(k.text(
            "Android 12+ only lets an app use the mic in the background if it started while the app was open. " +
                "So you turn the scheduler on once from this screen; it then waits in the background (persistent notification) " +
                "and starts/stops each job by itself. The green mic dot appears only while recording.",
            13f, p.sub), top = 6))
        content.addView(a)
    }

    private fun checkRow(parent: LinearLayout, label: String, ok: Boolean, fix: () -> Unit) {
        val r = k.row()
        r.addView(k.text(if (ok) "✓" else "!", 16f, if (ok) p.green else p.warn, bold = true).apply {
            gravity = Gravity.CENTER
            minWidth = k.dp(22)
        })
        r.addView(k.place(k.text(label, 14f, p.text), w = 0, weight = 1f, start = 8))
        if (!ok) r.addView(k.place(k.button("Fix", Kind.TONAL, fix).apply {
            setPadding(k.dp(16), k.dp(6), k.dp(16), k.dp(6))
        }, w = WRAP))
        parent.addView(k.place(r, top = 10))
    }
}
