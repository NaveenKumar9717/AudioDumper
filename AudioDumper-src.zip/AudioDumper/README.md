# AudioDumper v2: scheduled audio recorder (Android 12+)

## Features
- **Jobs**: start time, duration, repeat days (every day / weekdays / weekends / custom / once), auto-stop
- **Split files**: optional new file every 10/15/30/60 min
- **Save folder**: default `Internal storage/Recordings/AudioDumper`, or pick any folder
- **Recordings list**: tap to play, long-press to share or delete; warns if a file was silent
- **Record now**: 15 min / 30 min / 1 h / 2 h / until stopped
- **Log tab** with Share; **Settings**: quality, mic source, reliability checks
- Quick Settings tile + long-press app icon shortcuts (Scheduler on/off)

## How it works
Android 12+ only allows background mic use if it started while the app was open.
Turn the **Scheduler** on once in the app. It waits in the background (persistent notification)
and starts/stops each job itself. Exact alarms wake it on time from deep sleep.
After a reboot or app update, tap the notification to turn it back on.
