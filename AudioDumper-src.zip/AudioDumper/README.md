# AudioDumper — Step 1: service + logs + start/stop (no adb needed)

## Install (one time, needs a PC with Android Studio)
1. Android Studio → File → Open → this `AudioDumper` folder → wait for Gradle sync.
2. Build → Build App Bundle(s) / APK(s) → **Build APK(s)** → click "locate".
   File: `app/build/outputs/apk/debug/app-debug.apk`
3. Copy the APK to the phone (USB cable, Google Drive, WhatsApp to yourself…).
4. On the phone, tap the APK in My Files → allow "Install unknown apps" for that app → Install.
   Play Protect may warn "unrecognized app". That's because it's your own unsigned debug build.

## On the phone (one time)
- Open AudioDumper → **Start** → allow Microphone + Notifications.
- Tap **Disable battery optimization** → Allow.
- Samsung: Settings → Battery → Background usage limits → make sure AudioDumper
  is NOT in "Sleeping apps" / "Deep sleeping apps".

## Start / stop / kill
| What | How |
|---|---|
| Start | App → **Start**; or Quick Settings tile; or long-press app icon → "Start recording service" |
| Stop | Notification → **Stop**; App → **Stop**; tile; or long-press icon → "Stop recording service" |
| Kill hard | Settings → Apps → AudioDumper → **Force stop** |
| Is it running? | App status line, tile state, or the persistent notification + green mic dot |

Quick Settings tile: swipe down twice → pencil/Edit → drag "AudioDumper" into your tiles.
Tip: long-press a shortcut and drag it to the home screen for a one-tap button.

Why start always opens the app: Android 12+ only gives a background service mic access
if it was started while the app was on screen. MacroDroid started recording from the
background, so it got silence.

## Logs
The app screen shows the last 300 lines live (refreshes every 2 s).
**Share log** sends it to WhatsApp/Gmail/Drive so you can paste it to me.

Heartbeat line every 10 s:
```
2026-10-29 12:00:10.001 heartbeat uptime=600s screenOn=false micPeak=1840 silenced=false
```

## The test that matters
Start, lock the phone, talk near it for 2–3 minutes, unlock, look at the log.
- `screenOn=false` lines with `micPeak` in hundreds/thousands and `silenced=false` → the mic works locked. Ready for step 2.
- `micPeak=0` or `silenced=true` while locked → still muted. Share the log with me.

Also worth testing: swipe the app away from recents, and leave the phone idle for 1+ hour.
The heartbeat should keep ticking every 10 s.
